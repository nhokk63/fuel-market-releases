const FM_UI_BUILD=1090413;
'use strict';let checkedRelease=null,checkingRelease=false,installingRelease=false,updateAttempt=0,updateMessage='',releasePage=0;
const releaseState=()=>{try{return window.Updater?JSON.parse(Updater.state()):{apk:10900,ota:0,highest:0,url:''};}catch{return {apk:10900,ota:0,highest:0,url:''};}};
const versionName=n=>`${Math.floor(n/10000)}.${Math.floor(n/100)%100}.${n%100}`;
window.updateProgress=t=>{updateMessage=String(t);$('updatestatus').textContent=updateMessage;};
function releaseChoices(s=releaseState()){return {ota:!!(checkedRelease?.ota?.sequence>Math.max(s.ota,s.highest||0)&&checkedRelease.ota.minApk<=s.apk&&checkedRelease.ota.maxApk>=s.apk),apk:!!(checkedRelease?.apk?.versionCode>s.apk)};}
function renderReleaseNotes(){const notes=String(checkedRelease?.notes||'Bản OTA cập nhật giao diện. Bản APK cập nhật phần Android. Dữ liệu đã lưu được giữ lại.');const chunks=notes.match(/[\s\S]{1,180}(?:\s|$)|[\s\S]{1,180}/g)||[''];releasePage=Math.min(releasePage,chunks.length-1);$('updatenotes').textContent=chunks[releasePage];$('releasenext').hidden=chunks.length<2;$('releasenext').textContent=`Nội dung ${releasePage+1}/${chunks.length} ›`;}
function renderUpdates(){const s=releaseState(),c=releaseChoices(s);$('updateversion').textContent=`APK ${versionName(s.apk)} · OTA ${s.ota||'gốc'} · UI ${FM_UI_BUILD}`;$('updateurl').value=s.url;$('updatestatus').textContent=updateMessage||s.notice||'Tự kiểm tra khi mở ứng dụng';$('installota').disabled=installingRelease||checkingRelease||!c.ota;$('installapk').disabled=installingRelease||checkingRelease||!c.apk;$('checkupdates').disabled=checkingRelease||installingRelease;$('installcached').disabled=true;$('installcached').hidden=true;$('rollbackota').disabled=installingRelease||!s.canRollback;$('saveupdateurl').disabled=installingRelease||checkingRelease;$('openupdates').classList.toggle('available',c.ota||c.apk);$('openupdates').setAttribute('aria-label',c.ota||c.apk?'Có bản cập nhật mới':'Cập nhật ứng dụng');$('updatechecked').textContent=s.lastCheck?'Kiểm tra: '+new Date(s.lastCheck).toLocaleString('vi-VN'):'Chưa kiểm tra thành công';renderReleaseNotes();return s;}
async function checkUpdates(silent=false){if(checkingRelease||installingRelease||!window.Updater)return;checkingRelease=true;updateAttempt=Date.now();checkedRelease=null;updateProgress('Đang kiểm tra phiên bản…');renderUpdates();try{const source=new URL(releaseState().url);source.searchParams.set('_fmcheck',String(Date.now()));Updater.configure(source.href);checkedRelease=await bridgeCall('check',[],45000);const s=releaseState(),c=releaseChoices(s);releasePage=0;updateProgress(c.apk?'Có APK '+versionName(checkedRelease.apk.versionCode)+' · tải và cài trong app':c.ota?'Có OTA '+checkedRelease.ota.sequence+' · sẵn sàng áp dụng':'Đang dùng bản mới nhất trong kho');if(silent&&(c.ota||c.apk)&&readStore('update-announced','')!==JSON.stringify([checkedRelease.apk?.versionCode,checkedRelease.ota?.sequence])){writeStore('update-announced',JSON.stringify([checkedRelease.apk?.versionCode,checkedRelease.ota?.sequence]));toast('Có cập nhật ứng dụng · bấm biểu tượng ↓');}}catch(e){checkedRelease=null;updateProgress('Chưa kiểm tra được: '+e.message+' · có thể thử lại');}finally{checkingRelease=false;renderUpdates();}}
$('checkupdates').onclick=()=>checkUpdates();$('openupdates').onclick=()=>{go('updates');if(Date.now()-updateAttempt>60000)checkUpdates();};
$('releasenext').onclick=()=>{releasePage++;const notes=String(checkedRelease?.notes||'');if(releasePage*180>=notes.length)releasePage=0;renderReleaseNotes();};
$('saveupdateurl').onclick=()=>{if(!window.Updater)return;const input=prompt('Địa chỉ manifest đã ký của kho phát hành:',releaseState().url);if(input===null)return;try{const u=new URL(input.trim());if(u.protocol!=='https:'||u.username||u.password)throw Error();Updater.configure(u.href);checkedRelease=null;updateMessage='';renderUpdates();checkUpdates();}catch{updateProgress('Cần URL HTTPS của manifest đã ký');}};
for(const kind of ['ota','apk'])$('install'+kind).onclick=async()=>{
 if(installingRelease||checkingRelease||!window.Updater)return;
 await checkUpdates();if(!releaseChoices()[kind])return;
 installingRelease=true;renderUpdates();
 try{if(kind==='apk'){
 const item=checkedRelease.apk,u=new URL(item.url);if(u.protocol!=='https:'||!Number.isInteger(item.versionCode)||item.versionCode<=releaseState().apk)throw Error('Chưa có APK mới hợp lệ');
 u.searchParams.set('fmversion',String(item.versionCode));u.searchParams.set('fmhash',item.sha256);
 Updater.openSource(u.href);updateProgress('Đã mở trình duyệt để tải APK '+versionName(item.versionCode)+'. Mở file vừa tải để cài đè; không gỡ app. Sau cài, kiểm tra dòng APK bên trên.');
 }else{updateProgress('Đang tải và xác minh OTA…');await bridgeCall('install',[kind],180000);}
 }catch(e){updateProgress('Chưa cập nhật: '+e.message);}finally{installingRelease=false;renderUpdates();}
};
$('rollbackota').onclick=()=>{if(window.Updater&&!installingRelease&&confirm('Khôi phục giao diện trước? Dữ liệu đã lưu được giữ lại.'))Updater.rollback();};$('installcached').onclick=()=>{};
function autoCheckUpdates(){if(!document.hidden&&window.Updater&&Date.now()-updateAttempt>6*3600000)checkUpdates(true);}
renderUpdates();if(window.Updater){setTimeout(autoCheckUpdates,2000);document.addEventListener('visibilitychange',()=>{renderUpdates();autoCheckUpdates();});window.addEventListener('online',()=>{if(Date.now()-updateAttempt>60000)checkUpdates(true);});setInterval(autoCheckUpdates,60000);if(window.fmBootOk&&window.fmAgriBoot&&window.fmAiBoot)setTimeout(()=>Updater.readyFor?Updater.readyFor(FM_UI_BUILD):Updater.ready(),800);}

mountWatchlist();

installMarketIcons();

unifyMarketUI();
